/**
 * @version     CVS: 1.0.0
 * @package     com_tgriparti
 * @subpackage  mod_tgriparti
 * @copyright   2016 Todaro Giovanni - Consiglio Nazionale delle Ricerche -  Istituto per le Tecnologie Didattiche
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Todaro Giovanni <Info@todarogiovanni.eu>
 */


